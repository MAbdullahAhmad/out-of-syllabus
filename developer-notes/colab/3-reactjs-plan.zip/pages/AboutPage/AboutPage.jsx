import React from 'react';
import ApplicationLayout from '../../layouts/ApplicationLayout';

function AboutPage() {
    return (
        <ApplicationLayout>
            {/* Content */}
        </ApplicationLayout>
    );
}

export default AboutPage;
