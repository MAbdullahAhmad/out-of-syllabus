import React from 'react';

function ExampleComponent() {
    return (
        <div>
            <h2>Example Component</h2>
            <p>This is a simple example of a React component.</p>
        </div>
    );
}

export default ExampleComponent;
